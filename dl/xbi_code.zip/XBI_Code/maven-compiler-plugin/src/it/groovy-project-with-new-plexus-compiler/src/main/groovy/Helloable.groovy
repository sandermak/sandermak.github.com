interface Helloable {
	void sayHello()
}