public class MyClass
{

    public static void main( String[] args )
    {
        // the date constructor is deprecated and will cause a warning
        System.out.println( new java.util.Date( 2010, 8, 29 ) );
    }

}
